package com.nova.client.gui;

/** The one color the whole client (GUI, HUD, TargetESP...) is tinted with. */
public final class Theme {
    private static int rgb = 0x78BEFF;

    private Theme() { }

    public static void set(int newRgb) { rgb = newRgb & 0xFFFFFF; }
    public static int rgb() { return rgb; }
    public static int r() { return (rgb >> 16) & 0xFF; }
    public static int g() { return (rgb >> 8) & 0xFF; }
    public static int b() { return rgb & 0xFF; }

    /** Lighter, almost white version of the theme (used for the chain links, HUD pulse). */
    public static int lightR() { return light(r()); }
    public static int lightG() { return light(g()); }
    public static int lightB() { return light(b()); }
    private static int light(int c) { return c + (int) ((255 - c) * 0.82); }

    public static int argb(int alpha) { return (alpha << 24) | rgb; }

    /** 0 = theme color, 1 = light version. */
    public static int blend(float t) {
        int rr = (int) (r() + (lightR() - r()) * t);
        int gg = (int) (g() + (lightG() - g()) * t);
        int bb = (int) (b() + (lightB() - b()) * t);
        return 0xFF000000 | (rr << 16) | (gg << 8) | bb;
    }
}
