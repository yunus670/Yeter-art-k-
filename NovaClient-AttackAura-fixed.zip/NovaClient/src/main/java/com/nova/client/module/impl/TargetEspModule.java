package com.nova.client.module.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import com.nova.client.gui.Theme;
import com.nova.client.module.BooleanSetting;
import com.nova.client.module.Category;
import com.nova.client.module.ModeSetting;
import com.nova.client.module.Module;
import com.nova.client.module.NumberSetting;
import com.nova.client.module.ModuleManager;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/** Draws an effect around the player Aura is locked on. */
public final class TargetEspModule extends Module {
    /** Chain = a ring of linked chain links circling the target. Ring = a plain glowing ring. */
    public final ModeSetting mode = new ModeSetting("Mode", "Chain", "Chain", "Ring", "Box", "Spin Box");
    public final NumberSetting speed = new NumberSetting("Speed", 4.0, 1.0, 10.0, 0.5);
    public final NumberSetting size = new NumberSetting("Size", 1.0, 0.5, 2.0, 0.1);
    public final BooleanSetting bob = new BooleanSetting("Bob Up/Down", true);
    public final BooleanSetting box = new BooleanSetting("Box Under Effect", true);
    public final BooleanSetting throughWalls = new BooleanSetting("Through Walls", true);

    private static final int LINKS = 22;
    private static final int SEGMENTS = 12;

    public TargetEspModule() {
        super("TargetESP", "Effect around the Aura target.", Category.RENDER);
    }

    @Override
    public void onRender3D(MatrixStack matrices, Vec3d cam, float tickProgress) {
        AuraModule aura = ModuleManager.get(AuraModule.class);
        if (aura == null || !aura.isToggled()) return;
        PlayerEntity target = aura.getTarget();
        if (target == null || !target.isAlive()) return;

        Vec3d pos = target.getLerpedPos(tickProgress);
        double t = System.nanoTime() / 1.0e9 * speed.getValue() * 0.25;
        double height = target.getHeight();
        double y = pos.y + height * (bob.isEnabled() ? 0.5 + 0.38 * Math.sin(t * 5.0) : 0.5);
        double radius = (target.getWidth() * 0.5 + 0.38) * size.getValue();

        Matrix4f m = matrices.peek().getPositionMatrix();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        if (throughWalls.isEnabled()) RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        boolean boxMode = mode.is("Box");
        boolean spinMode = mode.is("Spin Box");
        if (boxMode || (box.isEnabled() && !spinMode)) {
            Box b = target.getBoundingBox().offset(pos.subtract(target.getPos()));
            if (boxMode) {
                // Box mode: pale translucent square around the target with light edges.
                b = b.expand(0.05);
                drawBox(m, cam, b, Theme.lightR(), Theme.lightG(), Theme.lightB(), 55);
                drawBoxEdges(m, cam, b, Theme.lightR(), Theme.lightG(), Theme.lightB(), 215, 0.012);
            } else {
                drawBox(m, cam, b, Theme.r(), Theme.g(), Theme.b(), 38);
            }
        }

        if (spinMode) drawSpinBox(m, cam, pos, target, t);

        if (!boxMode && !spinMode) {
            BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            if (mode.is("Chain")) {
                drawChain(buf, m, cam, new Vec3d(pos.x, y, pos.z), radius, t * Math.PI * 2.0);
            } else {
                drawRing(buf, m, cam, new Vec3d(pos.x, y, pos.z), radius);
            }
            BuiltBuffer built = buf.endNullable();
            if (built != null) BufferRenderer.drawWithGlobalProgram(built);
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    // ---- Chain: links alternate flat / upright, like a real chain bent into a circle ----
    private void drawChain(BufferBuilder buf, Matrix4f m, Vec3d cam, Vec3d center, double radius, double base) {
        double spacing = 2.0 * Math.PI * radius / LINKS;
        double halfLen = spacing * 0.85;
        double halfWid = spacing * 0.36;
        double thick = spacing * 0.11;
        Vec3d up = new Vec3d(0, 1, 0);

        for (int i = 0; i < LINKS; i++) {
            double a = base + i * (2.0 * Math.PI / LINKS);
            Vec3d radial = new Vec3d(Math.cos(a), 0, Math.sin(a));
            Vec3d tangent = new Vec3d(-Math.sin(a), 0, Math.cos(a));
            Vec3d c = center.add(radial.multiply(radius));
            Vec3d across = (i % 2 == 0) ? radial : up;

            // soft glow behind, solid white-blue link on top
            ribbon(buf, m, cam, c, tangent, across, halfLen, halfWid, thick * 2.6, Theme.r(), Theme.g(), Theme.b(), 55);
            ribbon(buf, m, cam, c, tangent, across, halfLen, halfWid, thick, Theme.lightR(), Theme.lightG(), Theme.lightB(), 235);
        }
    }

    // ---- Ring: a flat glowing ring ----
    private void drawRing(BufferBuilder buf, Matrix4f m, Vec3d cam, Vec3d center, double radius) {
        int n = 64;
        double w = 0.035;
        for (int pass = 0; pass < 2; pass++) {
            double wd = pass == 0 ? w * 2.6 : w;
            int r = pass == 0 ? Theme.r() : Theme.lightR(), g = pass == 0 ? Theme.g() : Theme.lightG(),
                    bl = pass == 0 ? Theme.b() : Theme.lightB(), al = pass == 0 ? 55 : 235;
            for (int k = 0; k < n; k++) {
                double a1 = 2.0 * Math.PI * k / n, a2 = 2.0 * Math.PI * (k + 1) / n;
                quad(buf, m, cam,
                        center.add(Math.cos(a1) * (radius + wd), 0, Math.sin(a1) * (radius + wd)),
                        center.add(Math.cos(a1) * (radius - wd), 0, Math.sin(a1) * (radius - wd)),
                        center.add(Math.cos(a2) * (radius - wd), 0, Math.sin(a2) * (radius - wd)),
                        center.add(Math.cos(a2) * (radius + wd), 0, Math.sin(a2) * (radius + wd)),
                        r, g, bl, al);
            }
        }
    }

    /** One oval link: a ribbon between two ellipses lying in the plane spanned by along/across. */
    private void ribbon(BufferBuilder buf, Matrix4f m, Vec3d cam, Vec3d c, Vec3d along, Vec3d across,
                        double l, double w, double th, int r, int g, int b, int a) {
        for (int k = 0; k < SEGMENTS; k++) {
            double t1 = 2.0 * Math.PI * k / SEGMENTS;
            double t2 = 2.0 * Math.PI * (k + 1) / SEGMENTS;
            quad(buf, m, cam,
                    ellipse(c, along, across, l + th, w + th, t1),
                    ellipse(c, along, across, l - th, w - th, t1),
                    ellipse(c, along, across, l - th, w - th, t2),
                    ellipse(c, along, across, l + th, w + th, t2),
                    r, g, b, a);
        }
    }

    private static Vec3d ellipse(Vec3d c, Vec3d along, Vec3d across, double l, double w, double theta) {
        return c.add(along.multiply(l * Math.cos(theta))).add(across.multiply(w * Math.sin(theta)));
    }

    // ---- Box ----
    private void drawBox(Matrix4f m, Vec3d cam, Box b, int r, int g, int bl, int a) {
        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        Vec3d p000 = new Vec3d(b.minX, b.minY, b.minZ), p100 = new Vec3d(b.maxX, b.minY, b.minZ);
        Vec3d p110 = new Vec3d(b.maxX, b.maxY, b.minZ), p010 = new Vec3d(b.minX, b.maxY, b.minZ);
        Vec3d p001 = new Vec3d(b.minX, b.minY, b.maxZ), p101 = new Vec3d(b.maxX, b.minY, b.maxZ);
        Vec3d p111 = new Vec3d(b.maxX, b.maxY, b.maxZ), p011 = new Vec3d(b.minX, b.maxY, b.maxZ);
        quad(buf, m, cam, p000, p100, p110, p010, r, g, bl, a); // north
        quad(buf, m, cam, p001, p101, p111, p011, r, g, bl, a); // south
        quad(buf, m, cam, p000, p001, p011, p010, r, g, bl, a); // west
        quad(buf, m, cam, p100, p101, p111, p110, r, g, bl, a); // east
        quad(buf, m, cam, p000, p100, p101, p001, r, g, bl, a); // bottom
        quad(buf, m, cam, p010, p110, p111, p011, r, g, bl, a); // top
        BuiltBuffer built = buf.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);
    }

    /**
     * A square box that spins around the target. Theme colored, turns red the moment the target is
     * hit and fades back while its hurt animation runs out.
     */
    private void drawSpinBox(Matrix4f m, Vec3d cam, Vec3d pos, PlayerEntity target, double time) {
        double s = (target.getWidth() * 0.5 + 0.28) * size.getValue();
        double y0 = pos.y - 0.05;
        double y1 = pos.y + target.getHeight() + 0.1;
        double theta = time * Math.PI * 2.0;

        float hit = Math.min(1.0F, target.hurtTime / 10.0F);
        int r = (int) (Theme.r() + (255 - Theme.r()) * hit);
        int g = (int) (Theme.g() + (60 - Theme.g()) * hit);
        int b = (int) (Theme.b() + (60 - Theme.b()) * hit);

        Vec3d[] bottom = new Vec3d[4];
        Vec3d[] top = new Vec3d[4];
        for (int k = 0; k < 4; k++) {
            double a = theta + Math.PI / 4.0 + k * Math.PI / 2.0;
            double dx = Math.cos(a) * s * Math.sqrt(2.0);
            double dz = Math.sin(a) * s * Math.sqrt(2.0);
            bottom[k] = new Vec3d(pos.x + dx, y0, pos.z + dz);
            top[k] = new Vec3d(pos.x + dx, y1, pos.z + dz);
        }

        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int k = 0; k < 4; k++) {
            int n = (k + 1) % 4;
            quad(buf, m, cam, bottom[k], bottom[n], top[n], top[k], r, g, b, 48); // side
        }
        quad(buf, m, cam, top[0], top[1], top[2], top[3], r, g, b, 30);
        quad(buf, m, cam, bottom[0], bottom[1], bottom[2], bottom[3], r, g, b, 30);
        for (int k = 0; k < 4; k++) {
            int n = (k + 1) % 4;
            beam(buf, m, cam, bottom[k], bottom[n], 0.012, r, g, b, 235);
            beam(buf, m, cam, top[k], top[n], 0.012, r, g, b, 235);
            beam(buf, m, cam, bottom[k], top[k], 0.012, r, g, b, 235);
        }
        BuiltBuffer built = buf.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);
    }

    /** A thin beam between two points of any direction (two crossing strips). */
    private static void beam(BufferBuilder buf, Matrix4f m, Vec3d cam, Vec3d a, Vec3d b, double w,
                             int r, int g, int bl, int al) {
        Vec3d d = b.subtract(a);
        if (d.lengthSquared() < 1.0E-9) return;
        d = d.normalize();
        Vec3d ref = Math.abs(d.y) > 0.99 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
        Vec3d p1 = d.crossProduct(ref).normalize().multiply(w);
        Vec3d p2 = d.crossProduct(p1).normalize().multiply(w);
        quad(buf, m, cam, a.add(p1), b.add(p1), b.subtract(p1), a.subtract(p1), r, g, bl, al);
        quad(buf, m, cam, a.add(p2), b.add(p2), b.subtract(p2), a.subtract(p2), r, g, bl, al);
    }

    /** The 12 edges of the box as thin beams. */
    private void drawBoxEdges(Matrix4f m, Vec3d cam, Box b, int r, int g, int bl, int a, double w) {
        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        double[] xs = {b.minX, b.maxX};
        double[] ys = {b.minY, b.maxY};
        double[] zs = {b.minZ, b.maxZ};
        for (double y : ys) for (double z : zs) beamX(buf, m, cam, b.minX, b.maxX, y, z, w, r, g, bl, a);
        for (double x : xs) for (double z : zs) beamY(buf, m, cam, x, b.minY, b.maxY, z, w, r, g, bl, a);
        for (double x : xs) for (double y : ys) beamZ(buf, m, cam, x, y, b.minZ, b.maxZ, w, r, g, bl, a);
        BuiltBuffer built = buf.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);
    }

    private static void beamX(BufferBuilder buf, Matrix4f m, Vec3d cam, double xa, double xb, double y, double z, double w,
                              int r, int g, int b, int a) {
        quad(buf, m, cam, new Vec3d(xa, y - w, z), new Vec3d(xb, y - w, z), new Vec3d(xb, y + w, z), new Vec3d(xa, y + w, z), r, g, b, a);
        quad(buf, m, cam, new Vec3d(xa, y, z - w), new Vec3d(xb, y, z - w), new Vec3d(xb, y, z + w), new Vec3d(xa, y, z + w), r, g, b, a);
    }

    private static void beamY(BufferBuilder buf, Matrix4f m, Vec3d cam, double x, double ya, double yb, double z, double w,
                              int r, int g, int b, int a) {
        quad(buf, m, cam, new Vec3d(x - w, ya, z), new Vec3d(x - w, yb, z), new Vec3d(x + w, yb, z), new Vec3d(x + w, ya, z), r, g, b, a);
        quad(buf, m, cam, new Vec3d(x, ya, z - w), new Vec3d(x, yb, z - w), new Vec3d(x, yb, z + w), new Vec3d(x, ya, z + w), r, g, b, a);
    }

    private static void beamZ(BufferBuilder buf, Matrix4f m, Vec3d cam, double x, double y, double za, double zb, double w,
                              int r, int g, int b, int a) {
        quad(buf, m, cam, new Vec3d(x - w, y, za), new Vec3d(x - w, y, zb), new Vec3d(x + w, y, zb), new Vec3d(x + w, y, za), r, g, b, a);
        quad(buf, m, cam, new Vec3d(x, y - w, za), new Vec3d(x, y - w, zb), new Vec3d(x, y + w, zb), new Vec3d(x, y + w, za), r, g, b, a);
    }

    private static void quad(BufferBuilder buf, Matrix4f m, Vec3d cam, Vec3d p1, Vec3d p2, Vec3d p3, Vec3d p4,
                             int r, int g, int b, int a) {
        vertex(buf, m, cam, p1, r, g, b, a);
        vertex(buf, m, cam, p2, r, g, b, a);
        vertex(buf, m, cam, p3, r, g, b, a);
        vertex(buf, m, cam, p4, r, g, b, a);
    }

    private static void vertex(BufferBuilder buf, Matrix4f m, Vec3d cam, Vec3d p, int r, int g, int b, int a) {
        buf.vertex(m, (float) (p.x - cam.x), (float) (p.y - cam.y), (float) (p.z - cam.z)).color(r, g, b, a);
    }
}
