package com.nova.client.module.impl;

import com.nova.client.gui.ClickGuiScreen;
import com.nova.client.module.Category;
import com.nova.client.module.Module;
import net.minecraft.client.MinecraftClient;

public final class ClickGuiModule extends Module {
    public ClickGuiModule() {
        super("ClickGui", "Opens the module menu.", Category.RENDER);
    }

    @Override
    public boolean hasKeybind() { return false; }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen instanceof ClickGuiScreen) mc.setScreen(null);
    }
}
